create
    definer = robot@`%` procedure test_two()
BEGIN
DECLARE i INT DEFAULT 11;

WHILE i < 51 DO
INSERT into t_devuser(ucode, uname, oid,groupid,upwd) VALUES (CONCAT('user0',i),CONCAT('test0',i), i,1,'afdd0b4ad2ec172c586e2150770fbf9e');
SET i = i+1;
end WHILE;

END;

